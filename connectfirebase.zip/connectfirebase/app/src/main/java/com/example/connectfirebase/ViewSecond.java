package com.example.connectfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ViewSecond extends AppCompatActivity {

TextView name,age,contact,height;
    DatabaseReference reff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_second);

        name =(TextView) findViewById(R.id.name);
        age = (TextView) findViewById(R.id.age);
        contact = (TextView) findViewById(R.id.contact);
        height = (TextView) findViewById(R.id.height);

        reff = FirebaseDatabase.getInstance().getReference().child("Member");
        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String na= dataSnapshot.child("name").getValue().toString();
                String a= dataSnapshot.child("age").getValue().toString();
                String co= dataSnapshot.child("contact").getValue().toString();
                String he= dataSnapshot.child("height").getValue().toString();


                name.setText(na);
                age.setText(a);
                contact.setText(co);
                height.setText(he);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
