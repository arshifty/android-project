package com.example.connectfirebase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class view extends AppCompatActivity {

    ListView viewdata;

    ArrayList<String> arrayList = new ArrayList<>();
    DatabaseReference reff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(view.this,android.R.layout.simple_list_item_1,arrayList);
        viewdata =(ListView) findViewById(R.id.viewdata);
        viewdata.setAdapter(arrayAdapter);

        reff = FirebaseDatabase.getInstance().getReference();

        reff.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {


                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String name = ds.child("name").getValue(String.class);
                    int age = ds.child("age").getValue(Integer.class);
                    Long phone =  ds.child("phone").getValue(Long.class);
                    float height = ds.child("height").getValue(float.class);

                    Log.d("TAG", name + " / " + age+ " / " + phone+ " / " + height);

                    String val = "Name : "+name+"\nAge : "+age+"\nContact : "+phone+"\nHeight : "+height;
                    arrayList.add(val);
                    arrayAdapter.notifyDataSetChanged();
                }


            ///    String value = dataSnapshot.getValue(String.class);
             ///   arrayList.add(value);
              ///  arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
