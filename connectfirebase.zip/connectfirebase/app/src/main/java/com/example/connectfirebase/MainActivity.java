package com.example.connectfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    EditText txtname,txtage,txtphone,txtheight;
    Button insertbtn;

    DatabaseReference reff;


    Member member;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this,"Firebase connection success",Toast.LENGTH_LONG).show();


        txtname=(EditText) findViewById(R.id.txtname);
        txtage=(EditText) findViewById(R.id.txtage);
        txtphone=(EditText) findViewById(R.id.txtphone);
        txtheight=(EditText) findViewById(R.id.txtheight);

        insertbtn=(Button) findViewById(R.id.insertbtn);
        member = new Member();
        reff = FirebaseDatabase.getInstance().getReference().child("Member");

        insertbtn.setOnClickListener(new View.OnClickListener()   {
                                         @Override
                                         public void onClick(View v) {

                                             String userid = reff.push().getKey();
                                             int age=Integer.parseInt(txtage.getText().toString().trim());
                                             Float height = Float.parseFloat(txtheight.getText().toString().trim());
                                             Long phone = Long.parseLong(txtphone.getText().toString().trim());

                                             member.setId(userid);
                                             member.setName(txtname.getText().toString().trim());
                                             member.setAge(age);
                                             member.setPhone(phone);
                                             member.setHeight(height);

                                            reff.push().setValue(member);

                                            Toast.makeText(MainActivity.this,"Firebase Insert success",Toast.LENGTH_LONG).show();

                                         }
                                     }

        );



    }
}
