package com.example.connectfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class home extends AppCompatActivity {

    Button homeinsert,homeview,viewnext,btnretrive;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        homeinsert=(Button) findViewById(R.id.homeinsert);
        homeview = (Button) findViewById(R.id.homeview);
        viewnext =(Button) findViewById(R.id.viewnext);
        btnretrive =(Button) findViewById(R.id.btnrRetriveData);

        homeinsert.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, MainActivity.class);
                startActivity(intent);
            }
        });

        homeview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, view.class);
                startActivity(intent);
            }
        });

        viewnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, view.class);
                startActivity(intent);
            }
        });


        btnretrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(home.this, RetriveData.class);
                startActivity(intent);
            }
        });

    }
}
