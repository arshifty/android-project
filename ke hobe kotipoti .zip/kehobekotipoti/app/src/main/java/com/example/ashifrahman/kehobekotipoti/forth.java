package com.example.ashifrahman.kehobekotipoti;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class forth extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forth);
    }


    public void onBackPressed()
    {
        super.onBackPressed();
    }
}
