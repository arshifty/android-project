package com.example.ashifrahman.kehobekotipoti;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class second extends AppCompatActivity {

    private RadioGroup radioGroupId2;
    private RadioButton radiobutton2;
    private Button btn2;
    private TextView txt2;

    private AlertDialog.Builder alertdialogbuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        radioGroupId2 = findViewById(R.id.radioGroupId2);
        btn2 = findViewById(R.id.btn2);
        txt2 = findViewById(R.id.txt2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int selectedId = radioGroupId2.getCheckedRadioButtonId();
                radiobutton2 = findViewById(selectedId);

                String val = radiobutton2.getText().toString();

                if(val.equals("Sheikh Hasina Wajed"))
                {

                    alertdialogbuilder = new AlertDialog.Builder(second.this);
                    alertdialogbuilder.setTitle(R.string.title_text2);
                    alertdialogbuilder.setMessage(R.string.message_text2);


                    alertdialogbuilder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });

                    alertdialogbuilder.setNegativeButton("Next", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(second.this,"Next Question",Toast.LENGTH_SHORT).show();

                            Intent obj = new Intent(second.this,third.class);
                            startActivity(obj);
                        }
                    });

                    alertdialogbuilder.setNeutralButton("Home", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(second.this,"Home Page",Toast.LENGTH_SHORT).show();


                            Intent obj = new Intent(second.this,MainActivity.class);
                            startActivity(obj);
                        }
                    });



                    AlertDialog alertdialog = alertdialogbuilder.create();
                    alertdialog.show();




                }

                else
                {

                    alertdialogbuilder = new AlertDialog.Builder(second.this);
                    alertdialogbuilder.setTitle(R.string.title_texta2);
                    alertdialogbuilder.setMessage(R.string.message_texta2);






                    alertdialogbuilder.setNeutralButton("Home", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(second.this,"Home Page",Toast.LENGTH_SHORT).show();


                            Intent obj = new Intent(second.this,MainActivity.class);
                            startActivity(obj);
                        }
                    });



                    AlertDialog alertdialog = alertdialogbuilder.create();
                    alertdialog.show();



                }


            }
        });


    }

    public void onBackPressed()
    {
        super.onBackPressed();
    }
}
