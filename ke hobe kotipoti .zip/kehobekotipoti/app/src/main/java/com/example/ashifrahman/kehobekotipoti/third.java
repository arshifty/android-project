package com.example.ashifrahman.kehobekotipoti;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class third extends AppCompatActivity {


    private RadioGroup radioGroupId3;
    private RadioButton radiobutton3;
    private Button btn3;
    private TextView txt3;

    private AlertDialog.Builder alertdialogbuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        radioGroupId3 = findViewById(R.id.radioGroupId3);
        btn3 = findViewById(R.id.btn3);
        txt3 = findViewById(R.id.txt3);

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int selectedId = radioGroupId3.getCheckedRadioButtonId();
                radiobutton3 = findViewById(selectedId);

                String val = radiobutton3.getText().toString();

                if(val.equals("Taka"))
                {
                    alertdialogbuilder = new AlertDialog.Builder(third.this);
                    alertdialogbuilder.setTitle(R.string.title_text3);
                    alertdialogbuilder.setMessage(R.string.message_text3);


                    alertdialogbuilder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });

                    alertdialogbuilder.setNegativeButton("Next", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(third.this,"Next Question",Toast.LENGTH_SHORT).show();

                            Intent obj = new Intent(third.this,forth.class);
                            startActivity(obj);
                        }
                    });

                    alertdialogbuilder.setNeutralButton("Home", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(third.this,"Home Page",Toast.LENGTH_SHORT).show();


                            Intent obj = new Intent(third.this,MainActivity.class);
                            startActivity(obj);
                        }
                    });



                    AlertDialog alertdialog = alertdialogbuilder.create();
                    alertdialog.show();



                }

                else
                {

                    alertdialogbuilder = new AlertDialog.Builder(third.this);
                    alertdialogbuilder.setTitle(R.string.title_texta3);
                    alertdialogbuilder.setMessage(R.string.message_texta3);






                    alertdialogbuilder.setNeutralButton("Home", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(third.this,"Home Page",Toast.LENGTH_SHORT).show();


                            Intent obj = new Intent(third.this,MainActivity.class);
                            startActivity(obj);
                        }
                    });



                    AlertDialog alertdialog = alertdialogbuilder.create();
                    alertdialog.show();



                }


            }
        });


    }

    public void onBackPressed()
    {
        super.onBackPressed();
    }
}
