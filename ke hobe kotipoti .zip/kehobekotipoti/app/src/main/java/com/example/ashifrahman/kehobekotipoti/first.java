package com.example.ashifrahman.kehobekotipoti;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class first extends AppCompatActivity {

    private RadioGroup radioGroupId;
    private RadioButton radiobutton;
    private Button btn1;
    private TextView txt1;
    private AlertDialog.Builder alertdialogbuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);


        radioGroupId = findViewById(R.id.radioGroupId);
        btn1 = findViewById(R.id.btn1);
        txt1 = findViewById(R.id.txt1);




        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int selectedId = radioGroupId.getCheckedRadioButtonId();
                radiobutton = findViewById(selectedId);

                String val = radiobutton.getText().toString();

                if(val.equals("Dhaka"))
                {

                    alertdialogbuilder = new AlertDialog.Builder(first.this);
                    alertdialogbuilder.setTitle(R.string.title_text1);
                    alertdialogbuilder.setMessage(R.string.message_text1);


                    alertdialogbuilder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });

                    alertdialogbuilder.setNegativeButton("Next", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(first.this,"Next Question",Toast.LENGTH_SHORT).show();

                            Intent obj = new Intent(first.this,second.class);
                            startActivity(obj);
                        }
                    });

                    alertdialogbuilder.setNeutralButton("Home", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(first.this,"Home Page",Toast.LENGTH_SHORT).show();


                            Intent obj = new Intent(first.this,MainActivity.class);
                            startActivity(obj);
                        }
                    });



                    AlertDialog alertdialog = alertdialogbuilder.create();
                    alertdialog.show();




                }

                else
                {

                    alertdialogbuilder = new AlertDialog.Builder(first.this);
                    alertdialogbuilder.setTitle(R.string.title_texta1);
                    alertdialogbuilder.setMessage(R.string.message_texta1);






                    alertdialogbuilder.setNeutralButton("Home", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(first.this,"Home Page",Toast.LENGTH_SHORT).show();


                            Intent obj = new Intent(first.this,MainActivity.class);
                            startActivity(obj);
                        }
                    });



                    AlertDialog alertdialog = alertdialogbuilder.create();
                    alertdialog.show();





                }


            }
        });
    }

    public void onBackPressed()
    {
            super.onBackPressed();
    }

}
